var mongoose = require("mongoose");
var Schema = mongoose.Schema;

var UserSchema = new Schema({
  name:{ type: String,},
  email:{type: String},
  Task: {
    type: String,
    
  },
  Status: {
    type: String,
    enum: ["Ongoing", "Completed", "Not yet started"],
    
  },
});

module.exports = User = mongoose.model("tasks", UserSchema);